package com.qr.gen;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import com.google.zxing.WriterException;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) throws WriterException, IOException {
		String allIds[] = {
				/*
				 * "Ezxa", "Ezxo", "Ezxl", "Ezxm", "Ezxn", "Ezxv", "Ezxx", "Ezxz", "Ezx1",
				 * "Ezx3", "Ezx6", "EzyB", "EzyK", "EzyM", "Ezym", "Ezyf", "Ezys", "Ezy1",
				 * "EzzI", "EzzU", "EzzZ", "Ezzg", "Ezzl", "Ezzn", "Ezzs", "Ezza", "Ezzf",
				 * "EzzV", "EzzW", "EzzX", "EzzY", "Ezzh", "Ezzi", "Ezzj", "Ezzk", "Ezzo",
				 * "Ezzp", "Ezzq", "Ezzr", "Ezzb", "Ezzc", "Ezzd", "Ezze", "Ezzx", "Ezzy",
				 * "Ezz8", "Ezz-", "Ezz_", "Ez0A", "Ez0D", "Ez0E", "Ez0F", "Ez0G", "Ezz7",
				 * "Ez0B", "Ez0C", "Ez0H", "Ez0O", "Ez0P", "Ez0a", "Ez1a", "Ez1x", "Ez1y",
				 * "Ez2H", "Ez1h", "Ez1i", "Ez1s", "Ez1t", "Ez16", "Ez2D", "Ez2E", "Ez1f",
				 * "Ez1g", "Ez1j", "Ez1k", "Ez1l", "Ez1m", "Ez1n", "Ez1o", "Ez1p", "Ez1r",
				 * "Ez1u", "Ez1v", "Ez1w", "Ez1z", "Ez10", "Ez11", "Ez12", "Ez13", "Ez14",
				 * "Ez15", "Ez2F", "Ez2G", "Ez2O", "Ez2P", "Ez2Z", "Ez2n", "Ez2L", "Ez2e",
				 * "Ez2f", "Ez2M", "Ez2N", "Ez2Q", "Ez2R", "Ez2S", "Ez2T", "Ez2U", "Ez2V",
				 * "Ez2W", "Ez2Y", "Ez2b", "Ez2c", "Ez2d", "Ez2g", "Ez2h", "Ez2i", "Ez2j",
				 * "Ez2k", "Ez2l", "Ez2m", "Ez2o", "Ez2p", "Ez2q"
				 */

				/*
				 * "Ez0S", "Ez0T", "Ez1n", "Ez1o", "Ez1p", "Ez1r", "Ez1u", "Ez1v", "Ez1w",
				 * "Ez1z", "Ez10", "Ez11", "Ez12", "Ez13", "Ez14", "Ez15", "Ez2F", "Ez2G",
				 * "Ez2O", "Ez2P", "Ez2Z", "Ez2n", "Ez2L", "Ez2e", "Ez2f", "Ez2M", "Ez2N",
				 * "Ez2Q", "Ez2R", "Ez2S", "Ez2T", "Ez2U", "Ez2V", "Ez2W", "Ez2Y", "Ez2b",
				 * "Ez2c", "Ez2d", "Ez2g", "Ez2h", "Ez2i", "Ez2j", "Ez2k", "Ez2l", "Ez2m",
				 * "Ez2o", "Ez2p", "Ez2q"
				 */

				"LVDM","LVDN","LVDO","LVDP","LVDQ","LVDR","LVDS","LVDT","LVDU","LVDV","LVDW","LVDX","LVDY","LVDZ","LVDa","LVDb","LVDc","LVDd","LVDe","LVDf","LVDg","LVDh","LVDi","LVDj","LkW1","LkW2","LkW3","LkW4","LkW5","LkW6","LkW7","LkW8","LkW9","LkW-","LkW_","LkXA","LkXB","LkXC","LkXD","LkXE","LkXF","LkXG","LkXH","LkXI","LkXJ","LkXK","LkXL","LkXM","LkXN","LkXO"
				};
		String[] allQrNames = {
				/*
				 * "3f_Tower-II-Ezxa","3f_Tower-II-Ezxo","3f_Tower-II-Ezxl","3f_Tower-II-Ezxm",
				 * "3f_Tower-II-Ezxn","4f_Tower-I-Ezxv",
				 * "4f_Tower-I-Ezxx","4f_Tower-I-Ezxz","4f_Tower-I-Ezx1","4f_Tower-I-Ezx3",
				 * "4f_Tower-I-Ezx6","4f_Tower-I-EzyB",
				 * "4f_Tower-I-EzyK","4f_Tower-I-EzyM","4f_Tower-I-Ezym","4f_Tower-I-Ezyf",
				 * "4f_Tower-II-Ezys","4f_Tower-II-Ezy1",
				 * "4f_Tower-II-EzzI","5f_Tower-I-EzzU","5f_Tower-I-EzzZ","5f_Tower-I-Ezzg",
				 * "5f_Tower-I-Ezzl","5f_Tower-I-Ezzn",
				 * "5f_Tower-I-Ezzs","5f_Tower-I-Ezza","5f_Tower-I-Ezzf","5f_Tower-I-EzzV",
				 * "5f_Tower-I-EzzW","5f_Tower-I-EzzX",
				 * "5f_Tower-I-EzzY","5f_Tower-I-Ezzh","5f_Tower-I-Ezzi","5f_Tower-I-Ezzj",
				 * "5f_Tower-I-Ezzk","5f_Tower-I-Ezzo",
				 * "5f_Tower-I-Ezzp","5f_Tower-I-Ezzq","5f_Tower-I-Ezzr","5f_Tower-I-Ezzb",
				 * "5f_Tower-I-Ezzc","5f_Tower-I-Ezzd",
				 * "5f_Tower-I-Ezze","5f_Tower-II-Ezzx","5f_Tower-II-Ezzy","5f_Tower-II-Ezz8",
				 * "5f_Tower-II-Ezz",
				 * "5f_Tower-II-Ezz_","5f_Tower-II-Ez0A","5f_Tower-II-Ez0D","5f_Tower-II-Ez0E",
				 * "5f_Tower-II-Ez0F","5f_Tower-II-Ez0G",
				 * "5f_Tower-II-Ezz7","5f_Tower-II-Ez0B","5f_Tower-II-Ez0C","5f_Tower-II-Ez0H",
				 * "6f_Tower-I-Ez0O","6f_Tower-I-Ez0P",
				 * "6f_Tower-I-Ez0a","PREMIUM_BLOCK-3_FLOOR_T-III-Ez1a",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez1x",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez1y","PREMIUM_BLOCK-3_FLOOR_T-III-Ez2H",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez1h",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez1i","PREMIUM_BLOCK-3_FLOOR_T-III-Ez1s",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez1t",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez16","PREMIUM_BLOCK-3_FLOOR_T-III-Ez2D",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez2E",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez1f","PREMIUM_BLOCK-3_FLOOR_T-III-Ez1g",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez1j",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez1k","PREMIUM_BLOCK-3_FLOOR_T-III-Ez1l",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez1m",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez1n","PREMIUM_BLOCK-3_FLOOR_T-III-Ez1o",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez1p",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez1r","PREMIUM_BLOCK-3_FLOOR_T-III-Ez1u",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez1v",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez1w","PREMIUM_BLOCK-3_FLOOR_T-III-Ez1z",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez10",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez11","PREMIUM_BLOCK-3_FLOOR_T-III-Ez12",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez13",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez14","PREMIUM_BLOCK-3_FLOOR_T-III-Ez15",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez2F",
				 * "PREMIUM_BLOCK-3_FLOOR_T-III-Ez2G","PREMIUM_BLOCK-4_FLOOR_T-III-Ez2O",
				 * "PREMIUM_BLOCK-4_FLOOR_T-III-Ez2P",
				 * "PREMIUM_BLOCK-4_FLOOR_T-III-Ez2Z","PREMIUM_BLOCK-4_FLOOR_T-III-Ez2n",
				 * "PREMIUM_BLOCK-4_FLOOR_T-III-Ez2L",
				 * "PREMIUM_BLOCK-4_FLOOR_T-III-Ez2e","PREMIUM_BLOCK-4_FLOOR_T-III-Ez2f",
				 * "PREMIUM_BLOCK-4_FLOOR_T-III-Ez2M",
				 * "PREMIUM_BLOCK-4_FLOOR_T-III-Ez2N","PREMIUM_BLOCK-4_FLOOR_T-III-Ez2Q",
				 * "PREMIUM_BLOCK-4_FLOOR_T-III-Ez2R",
				 * "PREMIUM_BLOCK-4_FLOOR_T-III-Ez2S","PREMIUM_BLOCK-4_FLOOR_T-III-Ez2T",
				 * "PREMIUM_BLOCK-4_FLOOR_T-III-Ez2U",
				 * "PREMIUM_BLOCK-4_FLOOR_T-III-Ez2V","PREMIUM_BLOCK-4_FLOOR_T-III-Ez2W",
				 * "PREMIUM_BLOCK-4_FLOOR_T-III-Ez2Y",
				 * "PREMIUM_BLOCK-4_FLOOR_T-III-Ez2b","PREMIUM_BLOCK-4_FLOOR_T-III-Ez2c",
				 * "PREMIUM_BLOCK-4_FLOOR_T-III-Ez2d",
				 * "PREMIUM_BLOCK-4_FLOOR_T-III-Ez2g","PREMIUM_BLOCK-4_FLOOR_T-III-Ez2h",
				 * "PREMIUM_BLOCK-4_FLOOR_T-III-Ez2i",
				 * "PREMIUM_BLOCK-4_FLOOR_T-III-Ez2j","PREMIUM_BLOCK-4_FLOOR_T-III-Ez2k",
				 * "PREMIUM_BLOCK-4_FLOOR_T-III-Ez2l",
				 * "PREMIUM_BLOCK-4_FLOOR_T-III-Ez2m","PREMIUM_BLOCK-4_FLOOR_T-III-Ez2o",
				 * "PREMIUM_BLOCK-4_FLOOR_T-III-Ez2p", "PREMIUM_BLOCK-4_FLOOR_T-III-Ez2q"
				 */
				/*
				  "6th Tower-I-Ez0S(a)-2604", "6th Tower-I-Ez0T(b)-2604",
				 * "PREMIUM BLOCK - 3 FLOOR T-III-4310", "PREMIUM BLOCK - 3 FLOOR T-III-4311",
				  "PREMIUM BLOCK - 3 FLOOR T-III-4312", "PREMIUM BLOCK - 3 FLOOR T-III-4314",
				  "PREMIUM BLOCK - 3 FLOOR T-III-4317", "PREMIUM BLOCK - 3 FLOOR T-III-4318",
				  "PREMIUM BLOCK - 3 FLOOR T-III-4319", "PREMIUM BLOCK - 3 FLOOR T-III-4322",
				  "PREMIUM BLOCK - 3 FLOOR T-III-4323", "PREMIUM BLOCK - 3 FLOOR T-III-4324",
				  "PREMIUM BLOCK - 3 FLOOR T-III-4325", "PREMIUM BLOCK - 3 FLOOR T-III-4326",
				  "PREMIUM BLOCK - 3 FLOOR T-III-4327", "PREMIUM BLOCK - 3 FLOOR T-III-4328",
				  "PREMIUM BLOCK - 3 FLOOR T-III-4340", "PREMIUM BLOCK - 3 FLOOR T-III-4341",
				  "PREMIUM BLOCK - 4 FLOOR T-III-4404", "PREMIUM BLOCK - 4 FLOOR T-III-4405",
				  "PREMIUM BLOCK - 4 FLOOR T-III-4415", "PREMIUM BLOCK - 4 FLOOR T-III-4429",
				  "PREMIUM BLOCK - 4 FLOOR T-III-4401", "PREMIUM BLOCK - 4 FLOOR T-III-4420",
				  "PREMIUM BLOCK - 4 FLOOR T-III-4421", "PREMIUM BLOCK - 4 FLOOR T-III-4402",
				  "PREMIUM BLOCK - 4 FLOOR T-III-4403", "PREMIUM BLOCK - 4 FLOOR T-III-4406",
				  "PREMIUM BLOCK - 4 FLOOR T-III-4407", "PREMIUM BLOCK - 4 FLOOR T-III-4408",
				  "PREMIUM BLOCK - 4 FLOOR T-III-4409", "PREMIUM BLOCK - 4 FLOOR T-III-4410",
				  "PREMIUM BLOCK - 4 FLOOR T-III-4411", "PREMIUM BLOCK - 4 FLOOR T-III-4412",
				  "PREMIUM BLOCK - 4 FLOOR T-III-4414", "PREMIUM BLOCK - 4 FLOOR T-III-4417",
				  "PREMIUM BLOCK - 4 FLOOR T-III-4418", "PREMIUM BLOCK - 4 FLOOR T-III-4419",
				  "PREMIUM BLOCK - 4 FLOOR T-III-4422", "PREMIUM BLOCK - 4 FLOOR T-III-4423",
				  "PREMIUM BLOCK - 4 FLOOR T-III-4424", "PREMIUM BLOCK - 4 FLOOR T-III-4425",
				  "PREMIUM BLOCK - 4 FLOOR T-III-4426", "PREMIUM BLOCK - 4 FLOOR T-III-4427",
				  "PREMIUM BLOCK - 4 FLOOR T-III-4428", "PREMIUM BLOCK - 4 FLOOR T-III-4430",
				  "PREMIUM BLOCK - 4 FLOOR T-III-4431", "PREMIUM BLOCK - 4 FLOOR T-III-4432"
				 
				"PREMIUM BLOCK - 3 FLOOR T-III-4330", "PREMIUM BLOCK - 3 FLOOR T-III-4331",
				"PREMIUM BLOCK - 3 FLOOR T-III-4332", "PREMIUM BLOCK - 3 FLOOR T-III-4333",
				"PREMIUM BLOCK - 3 FLOOR T-III-4334", "PREMIUM BLOCK - 3 FLOOR T-III-4335",
				"PREMIUM BLOCK - 3 FLOOR T-III-4336", "PREMIUM BLOCK - 3 FLOOR T-III-4337" */
				"gf_ground floor","lotus hospital, lakdi ka pul","1f_1st floor","2f_2nd floor","3f_3rd floor","1f_nicu","4f_4th floor","1f_picu","2f_single rooms-5",
				"2f_sharing room","3f_single rooms","3f_deluxe","3f_suite","4f_patient beds-10","4f_pre op-1","4f_ot-2","gf_pharmacy","gf_front office","gf_feeding room",
				"gf_call center","gf_reception","gf_patient waiting","2f_sharing room 209","2f_sharing room 211","gf consultation room 1","gf consultation room 2",
				"gf consultation room 3","gf consultation room 4","gf consultation room 5","gf consultation room 6","gf consultation room 7","gf consultation room 8",
				"gf consultation room 9","2f_sharing room 202","2f_sharing room 204","2f_sharing room 208","201-single room","203-single room","205-single room",
				"206-single room","207-single room","210-single room","212-single room","2f cubicle 1","2f cubicle 2","2f cubicle 3","2f cubicle 4","2f cubicle 5",
				"4f post-op-1","4f gyne ward"

		};
		ArrayList<String> ids = new ArrayList<String>();
		for (String str : allIds) {
			ids.add(str);
		}

		ArrayList<String> names = new ArrayList<String>();
		int count =1 ;
		for (String name : allQrNames) {
//			System.out.println(name);
			names.add(""+(count++)+"_"+name);
		}

//    	print ids : 

		for (int i = 0; i < ids.size(); i++) {
			String s = ids.get(i);
			String name = names.get(i);
			System.out.println(name);
			String qrCodeText = "https://qr.treatwellapp.com/?location=" + s + "&org=MMAV&language=hindi";
			String filePath = "qr/new/3/" + name + ".png";
			int size = 600;
			String fileType = "png";
			File qrFile = new File(filePath);
			QrGenerator.qrGenerator(qrFile, qrCodeText, size, fileType);
		}
//    	System.out.println(s);

//		
		System.out.println("DONE");
	}
}
